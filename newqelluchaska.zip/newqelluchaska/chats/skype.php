<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd"> 
<html xmlns="http://www.w3.org/1999/xhtml"> 
<head> 
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" /> 
<title>Machupicchu Travel Chat</title> 
<link rel="stylesheet" type="text/css" media="screen" href="chat.css" />
</head> 
<body> 
<div class="centro">
<h1>Converse con nosotros mediante<br /> Skype</h1> 
<p> 
	Llamar a <strong>mapitravel</strong><br /> 
	
	<a href="skype:mapitravel?call"><img src="http://media.perunoticias.net/images/skypeon.png" style="border: none;" width="182" height="44" alt="My status" /></a> 
</p> 
<p> 
	Llamar a <strong>agenciamachupicchu</strong><br /> 
	<a href="skype:agenciamachupicchu?call"><img src="http://media.perunoticias.net/images/skypeon.png" style="border: none;" width="182" height="44" alt="My status" /></a> 
</p> 
<p> 
	Llamar a <strong>reservashotelesperu</strong><br /> 
	<a href="skype:reservashotelesperu?call"><img src="http://media.perunoticias.net/images/skypeon.png" style="border: none;" width="182" height="44" alt="My status" /></a> 
</p> 
 
<p><strong>N</strong>ecesita <a href="http://www.skype.com/download/skype/" target="_blank">instalar el software</a> de Skype para podernos contactar.</p> 
</div>
</body> 
</html>